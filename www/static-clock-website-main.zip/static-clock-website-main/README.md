# Static Clock Website

[Developed by Ahmad Emran](https://codepen.io/ahmadbassamemran/pen/WdKQyx).
